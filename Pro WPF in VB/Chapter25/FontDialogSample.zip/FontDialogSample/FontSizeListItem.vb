Imports Microsoft.VisualBasic
Imports System
Imports System.Text
Imports System.Windows
Imports System.Windows.Documents
Imports System.Windows.Controls
Imports System.Windows.Media
Imports System.Windows.Markup
Imports System.Globalization

Friend Class FontSizeListItem
	Inherits TextBlock
	Implements IComparable
	Private _sizeInPoints As Double

	Public Sub New(ByVal sizeInPoints As Double)
		_sizeInPoints = sizeInPoints
		Me.Text = sizeInPoints.ToString()
	End Sub

	Public Overrides Function ToString() As String
		Return _sizeInPoints.ToString()
	End Function

	Public ReadOnly Property SizeInPoints() As Double
		Get
			Return _sizeInPoints
		End Get
	End Property

	Public ReadOnly Property SizeInPixels() As Double
		Get
			Return PointsToPixels(_sizeInPoints)
		End Get
	End Property

	Public Shared Function FuzzyEqual(ByVal a As Double, ByVal b As Double) As Boolean
		Return Math.Abs(a - b) < 0.01
	End Function

	Private Function CompareTo(ByVal obj As Object) As Integer Implements IComparable.CompareTo
		Dim value As Double

		If TypeOf obj Is Double Then
			value = CDbl(obj)
		Else
			If (Not Double.TryParse(obj.ToString(), value)) Then
				Return 1
			End If
		End If

		Return If(FuzzyEqual(_sizeInPoints, value), 0, If((_sizeInPoints < value), -1, 1))
	End Function

	Public Shared Function PointsToPixels(ByVal value As Double) As Double
		Return value * (96.0 / 72.0)
	End Function

	Public Shared Function PixelsToPoints(ByVal value As Double) As Double
		Return value * (72.0 / 96.0)
	End Function
End Class
