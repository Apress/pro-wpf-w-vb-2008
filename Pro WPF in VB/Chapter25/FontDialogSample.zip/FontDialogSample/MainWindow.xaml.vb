Public Class MainWindow

    Private Sub OnFontButtonClick(ByVal sender As Object, ByVal e As RoutedEventArgs)
        ShowFontDialog()
    End Sub

    Private Sub ShowFontDialog()
        Dim fontChooser As New FontChooser()
        fontChooser.Owner = Me

        fontChooser.SetPropertiesFromObject(textBox)
        fontChooser.PreviewSampleText = textBox.SelectedText

        If fontChooser.ShowDialog().Value Then
            fontChooser.ApplyPropertiesToObject(textBox)
        End If
    End Sub
End Class
