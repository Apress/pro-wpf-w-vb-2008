Imports Microsoft.VisualBasic
Imports System
Imports System.Windows
Imports System.Windows.Documents
Imports System.Windows.Controls
Imports System.Windows.Media
Imports System.Globalization

Friend Class FontFamilyListItem
	Inherits TextBlock
	Implements IComparable
	Private _displayName As String

	Public Sub New(ByVal fontFamily As FontFamily)
		_displayName = GetDisplayName(fontFamily)

		Me.FontFamily = fontFamily
		Me.Text = _displayName
		Me.ToolTip = _displayName

		' In the case of symbol font, apply the default message font to the text so it can be read.
		If IsSymbolFont(fontFamily) Then
			Dim range As New TextRange(Me.ContentStart, Me.ContentEnd)
			range.ApplyPropertyValue(TextBlock.FontFamilyProperty, SystemFonts.MessageFontFamily)
		End If
	End Sub

	Public Overrides Function ToString() As String
		Return _displayName
	End Function

	Private Function CompareTo(ByVal obj As Object) As Integer Implements IComparable.CompareTo
		Return String.Compare(_displayName, obj.ToString(), True, CultureInfo.CurrentCulture)
	End Function

	Friend Shared Function IsSymbolFont(ByVal fontFamily As FontFamily) As Boolean
		For Each typeface As Typeface In fontFamily.GetTypefaces()
			Try
				Dim face As GlyphTypeface
				If typeface.TryGetGlyphTypeface(face) Then
					Return face.Symbol
				End If
			Catch
			End Try
		Next
		Return False
	End Function

	Friend Shared Function GetDisplayName(ByVal family As FontFamily) As String
		Return NameDictionaryHelper.GetDisplayName(family.FamilyNames)
	End Function
End Class
