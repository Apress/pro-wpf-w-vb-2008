Imports System.Globalization
Imports System.Windows.Threading

Public Class FontChooser

#Region "Private fields and types"

    Private _familyCollection As ICollection(Of FontFamily) ' see FamilyCollection property
    Private _defaultSampleText As String
    Private _previewSampleText As String
    Private _pointsText As String

    Private _updatePending As Boolean ' indicates a call to OnUpdate is scheduled
    Private _familyListValid As Boolean ' indicates the list of font families is valid
    Private _typefaceListValid As Boolean ' indicates the list of typefaces is valid
    Private _typefaceListSelectionValid As Boolean ' indicates the current selection in the typeface list is valid
    Private _previewValid As Boolean ' indicates the preview control is valid
    Private _tabDictionary As Dictionary(Of TabItem, TabState) ' state and logic for each tab
    Private _currentFeature As DependencyProperty
    Private _currentFeaturePage As TypographyFeaturePage

    Private Shared ReadOnly CommonlyUsedFontSizes As Double() = New Double() {3.0, 4.0, 5.0, 6.0, 6.5, 7.0, 7.5, 8.0, 8.5, 9.0, 9.5, 10.0, 10.5, 11.0, 11.5, 12.0, 12.5, 13.0, 13.5, 14.0, 15.0, 16.0, 17.0, 18.0, 19.0, 20.0, 22.0, 24.0, 26.0, 28.0, 30.0, 32.0, 34.0, 36.0, 38.0, 40.0, 44.0, 48.0, 52.0, 56.0, 60.0, 64.0, 68.0, 72.0, 76.0, 80.0, 88.0, 96.0, 104.0, 112.0, 120.0, 128.0, 136.0, 144.0}

    ' Specialized metadata object for font chooser dependency properties
    Private Class FontPropertyMetadata
        Inherits FrameworkPropertyMetadata
        Public ReadOnly TargetProperty As DependencyProperty

        Public Sub New(ByVal defaultValue As Object, ByVal changeCallback As PropertyChangedCallback, ByVal targetProperty As DependencyProperty)
            MyBase.New(defaultValue, changeCallback)
            Me.TargetProperty = targetProperty
        End Sub
    End Class

    ' Specialized metadata object for typographic font chooser properties
    Private Class TypographicPropertyMetadata
        Inherits FontPropertyMetadata
        Public Sub New(ByVal defaultValue As Object, ByVal targetProperty As DependencyProperty, ByVal featurePage As TypographyFeaturePage, ByVal sampleTextTag As String)
            MyBase.New(defaultValue, _callback, targetProperty)
            Me.FeaturePage = featurePage
            Me.SampleTextTag = sampleTextTag
        End Sub

        Public ReadOnly FeaturePage As TypographyFeaturePage
        Public ReadOnly SampleTextTag As String

        Private Shared _callback As New PropertyChangedCallback(AddressOf FontChooser.TypographicPropertyChangedCallback)
    End Class

    ' Object used to initialize the right-hand side of the typographic properties tab
    Private Class TypographyFeaturePage
        Public Sub New(ByVal items As Item())
            Me.Items = items
        End Sub

        Public Sub New(ByVal enumType As Type)
            Dim names As String() = System.Enum.GetNames(enumType)
            Dim values As Array = System.Enum.GetValues(enumType)

            Items = New Item(names.Length - 1) {}

            For i As Integer = 0 To names.Length - 1
                Items(i) = New Item(names(i), values.GetValue(i))
            Next
        End Sub

        Public Shared ReadOnly BooleanFeaturePage As New TypographyFeaturePage(New Item() {New Item("Disabled", False), New Item("Enabled", True)})

        Public Shared ReadOnly IntegerFeaturePage As New TypographyFeaturePage(New Item() {New Item("_0", 0), New Item("_1", 1), New Item("_2", 2), New Item("_3", 3), New Item("_4", 4), New Item("_5", 5), New Item("_6", 6), New Item("_7", 7), New Item("_8", 8), New Item("_9", 9)})

        Public Structure Item
            Public Sub New(ByVal tag As String, ByVal value As Object)
                Me.Tag = tag
                Me.Value = value
            End Sub
            Public ReadOnly Tag As String
            Public ReadOnly Value As Object
        End Structure

        Public ReadOnly Items As Item()
    End Class

    Private Delegate Sub UpdateCallback()

    ' Encapsulates the state and initialization logic of a tab control item.
    Private Class TabState
        Public Sub New(ByVal initMethod As UpdateCallback)
            InitializeTab = initMethod
        End Sub

        Public IsValid As Boolean = False
        Public ReadOnly InitializeTab As UpdateCallback
    End Class

#End Region

#Region "Construction and initialization"

    Protected Overrides Sub OnInitialized(ByVal e As EventArgs)
        MyBase.OnInitialized(e)

        _defaultSampleText = previewTextBox.Text
        _previewSampleText = _defaultSampleText
        _pointsText = typefaceNameRun.Text

        ' Hook up events for the font family list and associated text box.
        AddHandler fontFamilyTextBox.SelectionChanged, AddressOf fontFamilyTextBox_SelectionChanged
        AddHandler fontFamilyTextBox.TextChanged, AddressOf fontFamilyTextBox_TextChanged
        AddHandler fontFamilyTextBox.PreviewKeyDown, AddressOf fontFamilyTextBox_PreviewKeyDown
        AddHandler fontFamilyList.SelectionChanged, AddressOf fontFamilyList_SelectionChanged

        ' Hook up events for the typeface list.
        AddHandler typefaceList.SelectionChanged, AddressOf typefaceList_SelectionChanged

        ' Hook up events for the font size list and associated text box.
        AddHandler sizeTextBox.TextChanged, AddressOf sizeTextBox_TextChanged
        AddHandler sizeTextBox.PreviewKeyDown, AddressOf sizeTextBox_PreviewKeyDown
        AddHandler sizeList.SelectionChanged, AddressOf sizeList_SelectionChanged

        ' Hook up events for text decoration check boxes.
        Dim textDecorationEventHandler As New RoutedEventHandler(AddressOf textDecorationCheckStateChanged)
        AddHandler underlineCheckBox.Checked, textDecorationEventHandler
        AddHandler underlineCheckBox.Unchecked, textDecorationEventHandler
        AddHandler baselineCheckBox.Checked, textDecorationEventHandler
        AddHandler baselineCheckBox.Unchecked, textDecorationEventHandler
        AddHandler strikethroughCheckBox.Checked, textDecorationEventHandler
        AddHandler strikethroughCheckBox.Unchecked, textDecorationEventHandler
        AddHandler overlineCheckBox.Checked, textDecorationEventHandler
        AddHandler overlineCheckBox.Unchecked, textDecorationEventHandler

        ' Initialize the dictionary that maps tab control items to handler objects.
        _tabDictionary = New Dictionary(Of TabItem, TabState)(tabControl.Items.Count)
        _tabDictionary.Add(samplesTab, New TabState(New UpdateCallback(AddressOf InitializeSamplesTab)))
        _tabDictionary.Add(typographyTab, New TabState(New UpdateCallback(AddressOf InitializeTypographyTab)))
        _tabDictionary.Add(descriptiveTextTab, New TabState(New UpdateCallback(AddressOf InitializeDescriptiveTextTab)))

        ' Hook up events for the tab control.
        AddHandler tabControl.SelectionChanged, AddressOf tabControl_SelectionChanged

        ' Initialize the list of font sizes and select the nearest size.
        For Each value As Double In CommonlyUsedFontSizes
            sizeList.Items.Add(New FontSizeListItem(value))
        Next
        OnSelectedFontSizeChanged(SelectedFontSize)

        ' Initialize the font family list and the current family.
        If (Not _familyListValid) Then
            InitializeFontFamilyList()
            _familyListValid = True
            OnSelectedFontFamilyChanged(SelectedFontFamily)
        End If

        ' Schedule background updates.
        ScheduleUpdate()
    End Sub

#End Region

#Region "Event handlers"

    Private Sub OnOKButtonClicked(ByVal sender As Object, ByVal e As RoutedEventArgs)
        Me.DialogResult = True
        Me.Close()
    End Sub

    Private Sub OnCancelButtonClicked(ByVal sender As Object, ByVal e As RoutedEventArgs)
        Me.Close()
    End Sub

    Private _fontFamilyTextBoxSelectionStart As Integer

    Private Sub fontFamilyTextBox_SelectionChanged(ByVal sender As Object, ByVal e As RoutedEventArgs)
        _fontFamilyTextBoxSelectionStart = fontFamilyTextBox.SelectionStart
    End Sub

    Private Sub fontFamilyTextBox_TextChanged(ByVal sender As Object, ByVal e As TextChangedEventArgs)
        Dim text As String = fontFamilyTextBox.Text

        ' Update the current list item.
        If SelectFontFamilyListItem(text) Is Nothing Then
            ' The text does not exactly match a family name so consider applying auto-complete behavior.
            ' However, only do so if the following conditions are met:
            '   (1)  The user is typing more text rather than deleting (i.e., the new text length is
            '        greater than the most recent selection start index), and
            '   (2)  The caret is at the end of the text box.
            If text.Length > _fontFamilyTextBoxSelectionStart AndAlso fontFamilyTextBox.SelectionStart = text.Length Then
                ' Get the current list item, which should be the nearest match for the text.
                Dim item As FontFamilyListItem = TryCast(fontFamilyList.Items.CurrentItem, FontFamilyListItem)
                If Not item Is Nothing Then
                    ' Does the text box text match the beginning of the family name?
                    Dim familyDisplayName As String = item.ToString()
                    If String.Compare(text, 0, familyDisplayName, 0, text.Length, True, CultureInfo.CurrentCulture) = 0 Then
                        ' Set the text box text to the complete family name and select the part not typed in.
                        fontFamilyTextBox.Text = familyDisplayName
                        fontFamilyTextBox.SelectionStart = text.Length
                        fontFamilyTextBox.SelectionLength = familyDisplayName.Length - text.Length
                    End If
                End If
            End If
        End If
    End Sub

    Private Sub sizeTextBox_TextChanged(ByVal sender As Object, ByVal e As TextChangedEventArgs)
        Dim sizeInPoints As Double
        If Double.TryParse(sizeTextBox.Text, sizeInPoints) Then
            Dim sizeInPixels As Double = FontSizeListItem.PointsToPixels(sizeInPoints)
            If (Not FontSizeListItem.FuzzyEqual(sizeInPixels, SelectedFontSize)) Then
                SelectedFontSize = sizeInPixels
            End If
        End If
    End Sub

    Private Sub fontFamilyTextBox_PreviewKeyDown(ByVal sender As Object, ByVal e As KeyEventArgs)
        OnComboBoxPreviewKeyDown(fontFamilyTextBox, fontFamilyList, e)
    End Sub

    Private Sub sizeTextBox_PreviewKeyDown(ByVal sender As Object, ByVal e As KeyEventArgs)
        OnComboBoxPreviewKeyDown(sizeTextBox, sizeList, e)
    End Sub

    Private Sub fontFamilyList_SelectionChanged(ByVal sender As Object, ByVal e As SelectionChangedEventArgs)
        Dim item As FontFamilyListItem = TryCast(fontFamilyList.SelectedItem, FontFamilyListItem)
        If Not item Is Nothing Then
            SelectedFontFamily = item.FontFamily
        End If
    End Sub

    Private Sub sizeList_SelectionChanged(ByVal sender As Object, ByVal e As SelectionChangedEventArgs)
        Dim item As FontSizeListItem = TryCast(sizeList.SelectedItem, FontSizeListItem)
        If Not item Is Nothing Then
            SelectedFontSize = item.SizeInPixels
        End If
    End Sub

    Private Sub typefaceList_SelectionChanged(ByVal sender As Object, ByVal e As SelectionChangedEventArgs)
        Dim item As TypefaceListItem = TryCast(typefaceList.SelectedItem, TypefaceListItem)
        If Not item Is Nothing Then
            SelectedFontWeight = item.FontWeight
            SelectedFontStyle = item.FontStyle
            SelectedFontStretch = item.FontStretch
        End If
    End Sub

    Private Sub textDecorationCheckStateChanged(ByVal sender As Object, ByVal e As RoutedEventArgs)
        Dim textDecorationCollection As New TextDecorationCollection()

        If underlineCheckBox.IsChecked.Value Then
            textDecorationCollection.Add(TextDecorations.Underline(0))
        End If
        If baselineCheckBox.IsChecked.Value Then
            textDecorationCollection.Add(TextDecorations.Baseline(0))
        End If
        If strikethroughCheckBox.IsChecked.Value Then
            textDecorationCollection.Add(TextDecorations.Strikethrough(0))
        End If
        If overlineCheckBox.IsChecked.Value Then
            textDecorationCollection.Add(TextDecorations.OverLine(0))
        End If

        textDecorationCollection.Freeze()
        SelectedTextDecorations = textDecorationCollection
    End Sub

    Private Sub tabControl_SelectionChanged(ByVal sender As Object, ByVal e As SelectionChangedEventArgs)
        Dim tab As TabState = CurrentTabState
        If Not tab Is Nothing AndAlso (Not tab.IsValid) Then
            tab.InitializeTab()
            tab.IsValid = True
        End If
    End Sub

    Private Sub featureList_SelectionChanged(ByVal sender As Object, ByVal e As SelectionChangedEventArgs)
        InitializeTypographyTab()
    End Sub

#End Region

#Region "Public properties and methods"

    ''' <summary>
    ''' Collection of font families to display in the font family list. By default this is Fonts.SystemFontFamilies,
    ''' but a client could set this to another collection returned by Fonts.GetFontFamilies, e.g., a collection of
    ''' application-defined fonts.
    ''' </summary>
    Public Property FontFamilyCollection() As ICollection(Of FontFamily)
        Get
            Return If((_familyCollection Is Nothing), Fonts.SystemFontFamilies, _familyCollection)
        End Get

        Set(ByVal value As ICollection(Of FontFamily))
            If Not value Is _familyCollection Then
                _familyCollection = value
                InvalidateFontFamilyList()
            End If
        End Set
    End Property

    ''' <summary>
    ''' Sets the font chooser selection properties to match the properites of the specified object.
    ''' </summary>
    Public Sub SetPropertiesFromObject(ByVal obj As DependencyObject)
        For Each [property] As DependencyProperty In _chooserProperties
            Dim metadata As FontPropertyMetadata = TryCast([property].GetMetadata(GetType(FontChooser)), FontPropertyMetadata)
            If Not metadata Is Nothing Then
                Me.SetValue([property], obj.GetValue(metadata.TargetProperty))
            End If
        Next
    End Sub

    ''' <summary>
    ''' Sets the properites of the specified object to match the font chooser selection properties.
    ''' </summary>
    Public Sub ApplyPropertiesToObject(ByVal obj As DependencyObject)
        For Each [property] As DependencyProperty In _chooserProperties
            Dim metadata As FontPropertyMetadata = TryCast([property].GetMetadata(GetType(FontChooser)), FontPropertyMetadata)
            If Not metadata Is Nothing Then
                obj.SetValue(metadata.TargetProperty, Me.GetValue([property]))
            End If
        Next
    End Sub

    Private Sub ApplyPropertiesToObjectExcept(ByVal obj As DependencyObject, ByVal except As DependencyProperty)
        For Each [property] As DependencyProperty In _chooserProperties
            If Not [property] Is except Then
                Dim metadata As FontPropertyMetadata = TryCast([property].GetMetadata(GetType(FontChooser)), FontPropertyMetadata)
                If Not metadata Is Nothing Then
                    obj.SetValue(metadata.TargetProperty, Me.GetValue([property]))
                End If
            End If
        Next
    End Sub

    ''' <summary>
    ''' Sample text used in the preview box and family and typeface samples tab.
    ''' </summary>
    Public Property PreviewSampleText() As String
        Get
            Return _previewSampleText
        End Get

        Set(ByVal value As String)
            Dim newValue As String
            newValue = If(String.IsNullOrEmpty(value), _defaultSampleText, value)
            If newValue <> _previewSampleText Then
                _previewSampleText = newValue

                ' Update the preview text box.
                previewTextBox.Text = newValue

                ' The preview sample text is also used in the family and typeface samples tab.
                InvalidateTab(samplesTab)
            End If
        End Set
    End Property

#End Region

#Region "Dependency properties for typographic features"

    Public Shared ReadOnly StandardLigaturesProperty As DependencyProperty = RegisterTypographicProperty(Typography.StandardLigaturesProperty)
    Public Property StandardLigatures() As Boolean
        Get
            Return CBool(GetValue(StandardLigaturesProperty))
        End Get
        Set(ByVal value As Boolean)
            SetValue(StandardLigaturesProperty, value)
        End Set
    End Property

    Public Shared ReadOnly ContextualLigaturesProperty As DependencyProperty = RegisterTypographicProperty(Typography.ContextualLigaturesProperty)
    Public Property ContextualLigatures() As Boolean
        Get
            Return CBool(GetValue(ContextualLigaturesProperty))
        End Get
        Set(ByVal value As Boolean)
            SetValue(ContextualLigaturesProperty, value)
        End Set
    End Property

    Public Shared ReadOnly DiscretionaryLigaturesProperty As DependencyProperty = RegisterTypographicProperty(Typography.DiscretionaryLigaturesProperty)
    Public Property DiscretionaryLigatures() As Boolean
        Get
            Return CBool(GetValue(DiscretionaryLigaturesProperty))
        End Get
        Set(ByVal value As Boolean)
            SetValue(DiscretionaryLigaturesProperty, value)
        End Set
    End Property

    Public Shared ReadOnly HistoricalLigaturesProperty As DependencyProperty = RegisterTypographicProperty(Typography.HistoricalLigaturesProperty)
    Public Property HistoricalLigatures() As Boolean
        Get
            Return CBool(GetValue(HistoricalLigaturesProperty))
        End Get
        Set(ByVal value As Boolean)
            SetValue(HistoricalLigaturesProperty, value)
        End Set
    End Property

    Public Shared ReadOnly ContextualAlternatesProperty As DependencyProperty = RegisterTypographicProperty(Typography.ContextualAlternatesProperty)
    Public Property ContextualAlternates() As Boolean
        Get
            Return CBool(GetValue(ContextualAlternatesProperty))
        End Get
        Set(ByVal value As Boolean)
            SetValue(ContextualAlternatesProperty, value)
        End Set
    End Property

    Public Shared ReadOnly HistoricalFormsProperty As DependencyProperty = RegisterTypographicProperty(Typography.HistoricalFormsProperty)
    Public Property HistoricalForms() As Boolean
        Get
            Return CBool(GetValue(HistoricalFormsProperty))
        End Get
        Set(ByVal value As Boolean)
            SetValue(HistoricalFormsProperty, value)
        End Set
    End Property

    Public Shared ReadOnly KerningProperty As DependencyProperty = RegisterTypographicProperty(Typography.KerningProperty)
    Public Property Kerning() As Boolean
        Get
            Return CBool(GetValue(KerningProperty))
        End Get
        Set(ByVal value As Boolean)
            SetValue(KerningProperty, value)
        End Set
    End Property

    Public Shared ReadOnly CapitalSpacingProperty As DependencyProperty = RegisterTypographicProperty(Typography.CapitalSpacingProperty)
    Public Property CapitalSpacing() As Boolean
        Get
            Return CBool(GetValue(CapitalSpacingProperty))
        End Get
        Set(ByVal value As Boolean)
            SetValue(CapitalSpacingProperty, value)
        End Set
    End Property

    Public Shared ReadOnly CaseSensitiveFormsProperty As DependencyProperty = RegisterTypographicProperty(Typography.CaseSensitiveFormsProperty)
    Public Property CaseSensitiveForms() As Boolean
        Get
            Return CBool(GetValue(CaseSensitiveFormsProperty))
        End Get
        Set(ByVal value As Boolean)
            SetValue(CaseSensitiveFormsProperty, value)
        End Set
    End Property

    Public Shared ReadOnly StylisticSet1Property As DependencyProperty = RegisterTypographicProperty(Typography.StylisticSet1Property)
    Public Property StylisticSet1() As Boolean
        Get
            Return CBool(GetValue(StylisticSet1Property))
        End Get
        Set(ByVal value As Boolean)
            SetValue(StylisticSet1Property, value)
        End Set
    End Property

    Public Shared ReadOnly StylisticSet2Property As DependencyProperty = RegisterTypographicProperty(Typography.StylisticSet2Property)
    Public Property StylisticSet2() As Boolean
        Get
            Return CBool(GetValue(StylisticSet2Property))
        End Get
        Set(ByVal value As Boolean)
            SetValue(StylisticSet2Property, value)
        End Set
    End Property

    Public Shared ReadOnly StylisticSet3Property As DependencyProperty = RegisterTypographicProperty(Typography.StylisticSet3Property)
    Public Property StylisticSet3() As Boolean
        Get
            Return CBool(GetValue(StylisticSet3Property))
        End Get
        Set(ByVal value As Boolean)
            SetValue(StylisticSet3Property, value)
        End Set
    End Property

    Public Shared ReadOnly StylisticSet4Property As DependencyProperty = RegisterTypographicProperty(Typography.StylisticSet4Property)
    Public Property StylisticSet4() As Boolean
        Get
            Return CBool(GetValue(StylisticSet4Property))
        End Get
        Set(ByVal value As Boolean)
            SetValue(StylisticSet4Property, value)
        End Set
    End Property

    Public Shared ReadOnly StylisticSet5Property As DependencyProperty = RegisterTypographicProperty(Typography.StylisticSet5Property)
    Public Property StylisticSet5() As Boolean
        Get
            Return CBool(GetValue(StylisticSet5Property))
        End Get
        Set(ByVal value As Boolean)
            SetValue(StylisticSet5Property, value)
        End Set
    End Property

    Public Shared ReadOnly StylisticSet6Property As DependencyProperty = RegisterTypographicProperty(Typography.StylisticSet6Property)
    Public Property StylisticSet6() As Boolean
        Get
            Return CBool(GetValue(StylisticSet6Property))
        End Get
        Set(ByVal value As Boolean)
            SetValue(StylisticSet6Property, value)
        End Set
    End Property

    Public Shared ReadOnly StylisticSet7Property As DependencyProperty = RegisterTypographicProperty(Typography.StylisticSet7Property)
    Public Property StylisticSet7() As Boolean
        Get
            Return CBool(GetValue(StylisticSet7Property))
        End Get
        Set(ByVal value As Boolean)
            SetValue(StylisticSet7Property, value)
        End Set
    End Property

    Public Shared ReadOnly StylisticSet8Property As DependencyProperty = RegisterTypographicProperty(Typography.StylisticSet8Property)
    Public Property StylisticSet8() As Boolean
        Get
            Return CBool(GetValue(StylisticSet8Property))
        End Get
        Set(ByVal value As Boolean)
            SetValue(StylisticSet8Property, value)
        End Set
    End Property

    Public Shared ReadOnly StylisticSet9Property As DependencyProperty = RegisterTypographicProperty(Typography.StylisticSet9Property)
    Public Property StylisticSet9() As Boolean
        Get
            Return CBool(GetValue(StylisticSet9Property))
        End Get
        Set(ByVal value As Boolean)
            SetValue(StylisticSet9Property, value)
        End Set
    End Property

    Public Shared ReadOnly StylisticSet10Property As DependencyProperty = RegisterTypographicProperty(Typography.StylisticSet10Property)
    Public Property StylisticSet10() As Boolean
        Get
            Return CBool(GetValue(StylisticSet10Property))
        End Get
        Set(ByVal value As Boolean)
            SetValue(StylisticSet10Property, value)
        End Set
    End Property

    Public Shared ReadOnly StylisticSet11Property As DependencyProperty = RegisterTypographicProperty(Typography.StylisticSet11Property)
    Public Property StylisticSet11() As Boolean
        Get
            Return CBool(GetValue(StylisticSet11Property))
        End Get
        Set(ByVal value As Boolean)
            SetValue(StylisticSet11Property, value)
        End Set
    End Property

    Public Shared ReadOnly StylisticSet12Property As DependencyProperty = RegisterTypographicProperty(Typography.StylisticSet12Property)
    Public Property StylisticSet12() As Boolean
        Get
            Return CBool(GetValue(StylisticSet12Property))
        End Get
        Set(ByVal value As Boolean)
            SetValue(StylisticSet12Property, value)
        End Set
    End Property

    Public Shared ReadOnly StylisticSet13Property As DependencyProperty = RegisterTypographicProperty(Typography.StylisticSet13Property)
    Public Property StylisticSet13() As Boolean
        Get
            Return CBool(GetValue(StylisticSet13Property))
        End Get
        Set(ByVal value As Boolean)
            SetValue(StylisticSet13Property, value)
        End Set
    End Property

    Public Shared ReadOnly StylisticSet14Property As DependencyProperty = RegisterTypographicProperty(Typography.StylisticSet14Property)
    Public Property StylisticSet14() As Boolean
        Get
            Return CBool(GetValue(StylisticSet14Property))
        End Get
        Set(ByVal value As Boolean)
            SetValue(StylisticSet14Property, value)
        End Set
    End Property

    Public Shared ReadOnly StylisticSet15Property As DependencyProperty = RegisterTypographicProperty(Typography.StylisticSet15Property)
    Public Property StylisticSet15() As Boolean
        Get
            Return CBool(GetValue(StylisticSet15Property))
        End Get
        Set(ByVal value As Boolean)
            SetValue(StylisticSet15Property, value)
        End Set
    End Property

    Public Shared ReadOnly StylisticSet16Property As DependencyProperty = RegisterTypographicProperty(Typography.StylisticSet16Property)
    Public Property StylisticSet16() As Boolean
        Get
            Return CBool(GetValue(StylisticSet16Property))
        End Get
        Set(ByVal value As Boolean)
            SetValue(StylisticSet16Property, value)
        End Set
    End Property

    Public Shared ReadOnly StylisticSet17Property As DependencyProperty = RegisterTypographicProperty(Typography.StylisticSet17Property)
    Public Property StylisticSet17() As Boolean
        Get
            Return CBool(GetValue(StylisticSet17Property))
        End Get
        Set(ByVal value As Boolean)
            SetValue(StylisticSet17Property, value)
        End Set
    End Property

    Public Shared ReadOnly StylisticSet18Property As DependencyProperty = RegisterTypographicProperty(Typography.StylisticSet18Property)
    Public Property StylisticSet18() As Boolean
        Get
            Return CBool(GetValue(StylisticSet18Property))
        End Get
        Set(ByVal value As Boolean)
            SetValue(StylisticSet18Property, value)
        End Set
    End Property

    Public Shared ReadOnly StylisticSet19Property As DependencyProperty = RegisterTypographicProperty(Typography.StylisticSet19Property)
    Public Property StylisticSet19() As Boolean
        Get
            Return CBool(GetValue(StylisticSet19Property))
        End Get
        Set(ByVal value As Boolean)
            SetValue(StylisticSet19Property, value)
        End Set
    End Property

    Public Shared ReadOnly StylisticSet20Property As DependencyProperty = RegisterTypographicProperty(Typography.StylisticSet20Property)
    Public Property StylisticSet20() As Boolean
        Get
            Return CBool(GetValue(StylisticSet20Property))
        End Get
        Set(ByVal value As Boolean)
            SetValue(StylisticSet20Property, value)
        End Set
    End Property

    Public Shared ReadOnly SlashedZeroProperty As DependencyProperty = RegisterTypographicProperty(Typography.SlashedZeroProperty, "Digits")
    Public Property SlashedZero() As Boolean
        Get
            Return CBool(GetValue(SlashedZeroProperty))
        End Get
        Set(ByVal value As Boolean)
            SetValue(SlashedZeroProperty, value)
        End Set
    End Property

    Public Shared ReadOnly MathematicalGreekProperty As DependencyProperty = RegisterTypographicProperty(Typography.MathematicalGreekProperty)
    Public Property MathematicalGreek() As Boolean
        Get
            Return CBool(GetValue(MathematicalGreekProperty))
        End Get
        Set(ByVal value As Boolean)
            SetValue(MathematicalGreekProperty, value)
        End Set
    End Property

    Public Shared ReadOnly EastAsianExpertFormsProperty As DependencyProperty = RegisterTypographicProperty(Typography.EastAsianExpertFormsProperty)
    Public Property EastAsianExpertForms() As Boolean
        Get
            Return CBool(GetValue(EastAsianExpertFormsProperty))
        End Get
        Set(ByVal value As Boolean)
            SetValue(EastAsianExpertFormsProperty, value)
        End Set
    End Property

    Public Shared ReadOnly FractionProperty As DependencyProperty = RegisterTypographicProperty(Typography.FractionProperty, "OneHalf")
    Public Property Fraction() As FontFraction
        Get
            Return CType(GetValue(FractionProperty), FontFraction)
        End Get
        Set(ByVal value As FontFraction)
            SetValue(FractionProperty, value)
        End Set
    End Property

    Public Shared ReadOnly VariantsProperty As DependencyProperty = RegisterTypographicProperty(Typography.VariantsProperty)
    Public Property Variants() As FontVariants
        Get
            Return CType(GetValue(VariantsProperty), FontVariants)
        End Get
        Set(ByVal value As FontVariants)
            SetValue(VariantsProperty, value)
        End Set
    End Property

    Public Shared ReadOnly CapitalsProperty As DependencyProperty = RegisterTypographicProperty(Typography.CapitalsProperty)
    Public Property Capitals() As FontCapitals
        Get
            Return CType(GetValue(CapitalsProperty), FontCapitals)
        End Get
        Set(ByVal value As FontCapitals)
            SetValue(CapitalsProperty, value)
        End Set
    End Property

    Public Shared ReadOnly NumeralStyleProperty As DependencyProperty = RegisterTypographicProperty(Typography.NumeralStyleProperty, "Digits")
    Public Property NumeralStyle() As FontNumeralStyle
        Get
            Return CType(GetValue(NumeralStyleProperty), FontNumeralStyle)
        End Get
        Set(ByVal value As FontNumeralStyle)
            SetValue(NumeralStyleProperty, value)
        End Set
    End Property

    Public Shared ReadOnly NumeralAlignmentProperty As DependencyProperty = RegisterTypographicProperty(Typography.NumeralAlignmentProperty, "Digits")
    Public Property NumeralAlignment() As FontNumeralAlignment
        Get
            Return CType(GetValue(NumeralAlignmentProperty), FontNumeralAlignment)
        End Get
        Set(ByVal value As FontNumeralAlignment)
            SetValue(NumeralAlignmentProperty, value)
        End Set
    End Property

    Public Shared ReadOnly EastAsianWidthsProperty As DependencyProperty = RegisterTypographicProperty(Typography.EastAsianWidthsProperty)
    Public Property EastAsianWidths() As FontEastAsianWidths
        Get
            Return CType(GetValue(EastAsianWidthsProperty), FontEastAsianWidths)
        End Get
        Set(ByVal value As FontEastAsianWidths)
            SetValue(EastAsianWidthsProperty, value)
        End Set
    End Property

    Public Shared ReadOnly EastAsianLanguageProperty As DependencyProperty = RegisterTypographicProperty(Typography.EastAsianLanguageProperty)
    Public Property EastAsianLanguage() As FontEastAsianLanguage
        Get
            Return CType(GetValue(EastAsianLanguageProperty), FontEastAsianLanguage)
        End Get
        Set(ByVal value As FontEastAsianLanguage)
            SetValue(EastAsianLanguageProperty, value)
        End Set
    End Property

    Public Shared ReadOnly AnnotationAlternatesProperty As DependencyProperty = RegisterTypographicProperty(Typography.AnnotationAlternatesProperty)
    Public Property AnnotationAlternates() As Integer
        Get
            Return CInt(Fix(GetValue(AnnotationAlternatesProperty)))
        End Get
        Set(ByVal value As Integer)
            SetValue(AnnotationAlternatesProperty, value)
        End Set
    End Property

    Public Shared ReadOnly StandardSwashesProperty As DependencyProperty = RegisterTypographicProperty(Typography.StandardSwashesProperty)
    Public Property StandardSwashes() As Integer
        Get
            Return CInt(Fix(GetValue(StandardSwashesProperty)))
        End Get
        Set(ByVal value As Integer)
            SetValue(StandardSwashesProperty, value)
        End Set
    End Property

    Public Shared ReadOnly ContextualSwashesProperty As DependencyProperty = RegisterTypographicProperty(Typography.ContextualSwashesProperty)
    Public Property ContextualSwashes() As Integer
        Get
            Return CInt(Fix(GetValue(ContextualSwashesProperty)))
        End Get
        Set(ByVal value As Integer)
            SetValue(ContextualSwashesProperty, value)
        End Set
    End Property

    Public Shared ReadOnly StylisticAlternatesProperty As DependencyProperty = RegisterTypographicProperty(Typography.StylisticAlternatesProperty)
    Public Property StylisticAlternates() As Integer
        Get
            Return CInt(Fix(GetValue(StylisticAlternatesProperty)))
        End Get
        Set(ByVal value As Integer)
            SetValue(StylisticAlternatesProperty, value)
        End Set
    End Property

    Private Shared Sub TypographicPropertyChangedCallback(ByVal obj As DependencyObject, ByVal e As DependencyPropertyChangedEventArgs)
        Dim chooser As FontChooser = TryCast(obj, FontChooser)
        If Not chooser Is Nothing Then
            chooser.InvalidatePreview()
        End If
    End Sub

#End Region

#Region "Other dependency properties"

    Public Shared ReadOnly SelectedFontFamilyProperty As DependencyProperty = RegisterFontProperty("SelectedFontFamily", TextBlock.FontFamilyProperty, New PropertyChangedCallback(AddressOf SelectedFontFamilyChangedCallback))
    Public Property SelectedFontFamily() As FontFamily
        Get
            Return TryCast(GetValue(SelectedFontFamilyProperty), FontFamily)
        End Get
        Set(ByVal value As FontFamily)
            SetValue(SelectedFontFamilyProperty, value)
        End Set
    End Property
    Private Shared Sub SelectedFontFamilyChangedCallback(ByVal obj As DependencyObject, ByVal e As DependencyPropertyChangedEventArgs)
        CType(obj, FontChooser).OnSelectedFontFamilyChanged(TryCast(e.NewValue, FontFamily))
    End Sub

    Public Shared ReadOnly SelectedFontWeightProperty As DependencyProperty = RegisterFontProperty("SelectedFontWeight", TextBlock.FontWeightProperty, New PropertyChangedCallback(AddressOf SelectedTypefaceChangedCallback))
    Public Property SelectedFontWeight() As FontWeight
        Get
            Return CType(GetValue(SelectedFontWeightProperty), FontWeight)
        End Get
        Set(ByVal value As FontWeight)
            SetValue(SelectedFontWeightProperty, value)
        End Set
    End Property

    Public Shared ReadOnly SelectedFontStyleProperty As DependencyProperty = RegisterFontProperty("SelectedFontStyle", TextBlock.FontStyleProperty, New PropertyChangedCallback(AddressOf SelectedTypefaceChangedCallback))
    Public Property SelectedFontStyle() As FontStyle
        Get
            Return CType(GetValue(SelectedFontStyleProperty), FontStyle)
        End Get
        Set(ByVal value As FontStyle)
            SetValue(SelectedFontStyleProperty, value)
        End Set
    End Property

    Public Shared ReadOnly SelectedFontStretchProperty As DependencyProperty = RegisterFontProperty("SelectedFontStretch", TextBlock.FontStretchProperty, New PropertyChangedCallback(AddressOf SelectedTypefaceChangedCallback))
    Public Property SelectedFontStretch() As FontStretch
        Get
            Return CType(GetValue(SelectedFontStretchProperty), FontStretch)
        End Get
        Set(ByVal value As FontStretch)
            SetValue(SelectedFontStretchProperty, value)
        End Set
    End Property

    Private Shared Sub SelectedTypefaceChangedCallback(ByVal obj As DependencyObject, ByVal e As DependencyPropertyChangedEventArgs)
        CType(obj, FontChooser).InvalidateTypefaceListSelection()
    End Sub

    Public Shared ReadOnly SelectedFontSizeProperty As DependencyProperty = RegisterFontProperty("SelectedFontSize", TextBlock.FontSizeProperty, New PropertyChangedCallback(AddressOf SelectedFontSizeChangedCallback))
    Public Property SelectedFontSize() As Double
        Get
            Return CDbl(GetValue(SelectedFontSizeProperty))
        End Get
        Set(ByVal value As Double)
            SetValue(SelectedFontSizeProperty, value)
        End Set
    End Property
    Private Shared Sub SelectedFontSizeChangedCallback(ByVal obj As DependencyObject, ByVal e As DependencyPropertyChangedEventArgs)
        CType(obj, FontChooser).OnSelectedFontSizeChanged(CDbl(e.NewValue))
    End Sub

    Public Shared ReadOnly SelectedTextDecorationsProperty As DependencyProperty = RegisterFontProperty("SelectedTextDecorations", TextBlock.TextDecorationsProperty, New PropertyChangedCallback(AddressOf SelectedTextDecorationsChangedCallback))
    Public Property SelectedTextDecorations() As TextDecorationCollection
        Get
            Return TryCast(GetValue(SelectedTextDecorationsProperty), TextDecorationCollection)
        End Get
        Set(ByVal value As TextDecorationCollection)
            SetValue(SelectedTextDecorationsProperty, value)
        End Set
    End Property
    Private Shared Sub SelectedTextDecorationsChangedCallback(ByVal obj As DependencyObject, ByVal e As DependencyPropertyChangedEventArgs)
        Dim chooser As FontChooser = CType(obj, FontChooser)
        chooser.OnTextDecorationsChanged()
    End Sub

#End Region

#Region "Dependency property helper functions"

    ' Helper function for registering typographic dependency properties with property-specific sample text.
    Private Shared Function RegisterTypographicProperty(ByVal targetProperty As DependencyProperty, ByVal sampleTextTag As String) As DependencyProperty
        Dim t As Type = targetProperty.PropertyType

        Dim featurePage As TypographyFeaturePage
        featurePage = If((t Is GetType(Boolean)), TypographyFeaturePage.BooleanFeaturePage, If((t Is GetType(Integer)), TypographyFeaturePage.IntegerFeaturePage, New TypographyFeaturePage(t)))

        Return DependencyProperty.Register(targetProperty.Name, t, GetType(FontChooser), New TypographicPropertyMetadata(targetProperty.DefaultMetadata.DefaultValue, targetProperty, featurePage, sampleTextTag))
    End Function

    ' Helper function for registering typographic dependency properties with default sample text for the type.
    Private Shared Function RegisterTypographicProperty(ByVal targetProperty As DependencyProperty) As DependencyProperty
        Return RegisterTypographicProperty(targetProperty, Nothing)
    End Function

    ' Helper function for registering font chooser dependency properties other than typographic properties.
    Private Shared Function RegisterFontProperty(ByVal propertyName As String, ByVal targetProperty As DependencyProperty, ByVal changeCallback As PropertyChangedCallback) As DependencyProperty
        Return DependencyProperty.Register(propertyName, targetProperty.PropertyType, GetType(FontChooser), New FontPropertyMetadata(targetProperty.DefaultMetadata.DefaultValue, changeCallback, targetProperty))
    End Function

#End Region

#Region "Dependency property tables"

    ' Array of all font chooser dependency properties
    ' typography properties
    ' other properties
    Private Shared ReadOnly _chooserProperties As DependencyProperty() = New DependencyProperty() {StandardLigaturesProperty, ContextualLigaturesProperty, DiscretionaryLigaturesProperty, HistoricalLigaturesProperty, ContextualAlternatesProperty, HistoricalFormsProperty, KerningProperty, CapitalSpacingProperty, CaseSensitiveFormsProperty, StylisticSet1Property, StylisticSet2Property, StylisticSet3Property, StylisticSet4Property, StylisticSet5Property, StylisticSet6Property, StylisticSet7Property, StylisticSet8Property, StylisticSet9Property, StylisticSet10Property, StylisticSet11Property, StylisticSet12Property, StylisticSet13Property, StylisticSet14Property, StylisticSet15Property, StylisticSet16Property, StylisticSet17Property, StylisticSet18Property, StylisticSet19Property, StylisticSet20Property, SlashedZeroProperty, MathematicalGreekProperty, EastAsianExpertFormsProperty, FractionProperty, VariantsProperty, CapitalsProperty, NumeralStyleProperty, NumeralAlignmentProperty, EastAsianWidthsProperty, EastAsianLanguageProperty, AnnotationAlternatesProperty, StandardSwashesProperty, ContextualSwashesProperty, StylisticAlternatesProperty, SelectedFontFamilyProperty, SelectedFontWeightProperty, SelectedFontStyleProperty, SelectedFontStretchProperty, SelectedFontSizeProperty, SelectedTextDecorationsProperty}

#End Region

#Region "Property change handlers"

    ' Handle changes to the SelectedFontFamily property
    Private Sub OnSelectedFontFamilyChanged(ByVal family As FontFamily)
        ' If the family list is not valid do nothing for now. 
        ' We'll be called again after the list is initialized.
        If _familyListValid Then
            ' Select the family in the list; this will return null if the family is not in the list.
            Dim item As FontFamilyListItem = SelectFontFamilyListItem(family)

            ' Set the text box to the family name, if it isn't already.
            Dim displayName As String
            displayName = If((Not item Is Nothing), item.ToString(), FontFamilyListItem.GetDisplayName(family))
            If String.Compare(fontFamilyTextBox.Text, displayName, True, CultureInfo.CurrentCulture) <> 0 Then
                fontFamilyTextBox.Text = displayName
            End If

            ' The typeface list is no longer valid; update it in the background to improve responsiveness.
            InvalidateTypefaceList()
        End If
    End Sub

    ' Handle changes to the SelectedFontSize property
    Private Sub OnSelectedFontSizeChanged(ByVal sizeInPixels As Double)
        ' Select the list item, if the size is in the list.
        Dim sizeInPoints As Double = FontSizeListItem.PixelsToPoints(sizeInPixels)
        If (Not SelectListItem(sizeList, sizeInPoints)) Then
            sizeList.SelectedIndex = -1
        End If

        ' Set the text box contents if it doesn't already match the current size.
        Dim textBoxValue As Double
        If (Not Double.TryParse(sizeTextBox.Text, textBoxValue)) OrElse (Not FontSizeListItem.FuzzyEqual(textBoxValue, sizeInPoints)) Then
            sizeTextBox.Text = sizeInPoints.ToString()
        End If

        ' Schedule background updates.
        InvalidateTab(typographyTab)
        InvalidatePreview()
    End Sub

    ' Handle changes to any of the text decoration properties.
    Private Sub OnTextDecorationsChanged()
        Dim underline As Boolean = False
        Dim baseline As Boolean = False
        Dim strikethrough As Boolean = False
        Dim overline As Boolean = False

        Dim textDecorations As TextDecorationCollection = SelectedTextDecorations
        If Not textDecorations Is Nothing Then
            For Each td As TextDecoration In textDecorations
                Select Case td.Location
                    Case TextDecorationLocation.Underline
                        underline = True
                    Case TextDecorationLocation.Baseline
                        baseline = True
                    Case TextDecorationLocation.Strikethrough
                        strikethrough = True
                    Case TextDecorationLocation.OverLine
                        overline = True
                End Select
            Next
        End If

        underlineCheckBox.IsChecked = underline
        baselineCheckBox.IsChecked = baseline
        strikethroughCheckBox.IsChecked = strikethrough
        overlineCheckBox.IsChecked = overline

        ' Schedule background updates.
        InvalidateTab(typographyTab)
        InvalidatePreview()
    End Sub

#End Region

#Region "Background update logic"

    ' Schedule background initialization of the font famiy list.
    Private Sub InvalidateFontFamilyList()
        If _familyListValid Then
            InvalidateTypefaceList()

            fontFamilyList.Items.Clear()
            fontFamilyTextBox.Clear()
            _familyListValid = False

            ScheduleUpdate()
        End If
    End Sub

    ' Schedule background initialization of the typeface list.
    Private Sub InvalidateTypefaceList()
        If _typefaceListValid Then
            typefaceList.Items.Clear()
            _typefaceListValid = False

            ScheduleUpdate()
        End If
    End Sub

    ' Schedule background selection of the current typeface list item.
    Private Sub InvalidateTypefaceListSelection()
        If _typefaceListSelectionValid Then
            _typefaceListSelectionValid = False
            ScheduleUpdate()
        End If
    End Sub

    ' Mark a specific tab as invalid and schedule background initialization if necessary.
    Private Sub InvalidateTab(ByVal tab As TabItem)
        Dim tabState As TabState
        If _tabDictionary.TryGetValue(tab, tabState) Then
            If tabState.IsValid Then
                tabState.IsValid = False

                If tabControl.SelectedItem Is tab Then
                    ScheduleUpdate()
                End If
            End If
        End If
    End Sub

    ' Mark all the tabs as invalid and schedule background initialization of the current tab.
    Private Sub InvalidateTabs()
        For Each item As KeyValuePair(Of TabItem, TabState) In _tabDictionary
            item.Value.IsValid = False
        Next

        ScheduleUpdate()
    End Sub

    ' Schedule background initialization of the preview control.
    Private Sub InvalidatePreview()
        If _previewValid Then
            _previewValid = False
            ScheduleUpdate()
        End If
    End Sub

    ' Schedule background initialization.
    Private Sub ScheduleUpdate()
        If (Not _updatePending) Then
            Dispatcher.BeginInvoke(DispatcherPriority.ContextIdle, New UpdateCallback(AddressOf OnUpdate))
            _updatePending = True
        End If
    End Sub

    ' Dispatcher callback that performs background initialization.
    Private Sub OnUpdate()
        _updatePending = False

        If (Not _familyListValid) Then
            ' Initialize the font family list.
            InitializeFontFamilyList()
            _familyListValid = True
            OnSelectedFontFamilyChanged(SelectedFontFamily)

            ' Defer any other initialization until later.
            ScheduleUpdate()
        ElseIf (Not _typefaceListValid) Then
            ' Initialize the typeface list.
            InitializeTypefaceList()
            _typefaceListValid = True

            ' Select the current typeface in the list.
            InitializeTypefaceListSelection()
            _typefaceListSelectionValid = True

            ' Defer any other initialization until later.
            ScheduleUpdate()
        ElseIf (Not _typefaceListSelectionValid) Then
            ' Select the current typeface in the list.
            InitializeTypefaceListSelection()
            _typefaceListSelectionValid = True

            ' Defer any other initialization until later.
            ScheduleUpdate()
        Else
            ' Perform any remaining initialization.
            Dim tab As TabState = CurrentTabState
            If Not tab Is Nothing AndAlso (Not tab.IsValid) Then
                ' Initialize the current tab.
                tab.InitializeTab()
                tab.IsValid = True
            End If
            If (Not _previewValid) Then
                ' Initialize the preview control.
                InitializePreview()
                _previewValid = True
            End If
        End If
    End Sub

#End Region

#Region "Content initialization"

    Private Sub InitializeFontFamilyList()
        Dim familyCollection As ICollection(Of FontFamily) = FontFamilyCollection
        If Not familyCollection Is Nothing Then
            Dim items As FontFamilyListItem() = New FontFamilyListItem(familyCollection.Count - 1) {}

            Dim i As Integer = 0

            For Each family As FontFamily In familyCollection
                items(i) = New FontFamilyListItem(family)
                i += 1
            Next

            Array.Sort(Of FontFamilyListItem)(items)

            For Each item As FontFamilyListItem In items
                fontFamilyList.Items.Add(item)
            Next
        End If
    End Sub

    Private Sub InitializeTypefaceList()
        Dim family As FontFamily = SelectedFontFamily
        If Not family Is Nothing Then
            Dim faceCollection As ICollection(Of Typeface) = family.GetTypefaces()

            Dim items As TypefaceListItem() = New TypefaceListItem(faceCollection.Count - 1) {}

            Dim i As Integer = 0

            For Each face As Typeface In faceCollection
                items(i) = New TypefaceListItem(face)
                i += 1
            Next

            Array.Sort(Of TypefaceListItem)(items)

            For Each item As TypefaceListItem In items
                typefaceList.Items.Add(item)
            Next
        End If
    End Sub

    Private Sub InitializeTypefaceListSelection()
        ' If the typeface list is not valid, do nothing for now.
        ' We'll be called again after the list is initialized.
        If _typefaceListValid Then
            Dim typeface As New Typeface(SelectedFontFamily, SelectedFontStyle, SelectedFontWeight, SelectedFontStretch)

            ' Select the typeface in the list.
            SelectTypefaceListItem(typeface)

            ' Schedule background updates.
            InvalidateTabs()
            InvalidatePreview()
        End If
    End Sub

    Private Sub InitializeFeatureList()
        Dim items As TypographicFeatureListItem() = New TypographicFeatureListItem(_chooserProperties.Length - 1) {}

        Dim count As Integer = 0

        For Each [property] As DependencyProperty In _chooserProperties
            If TypeOf [property].GetMetadata(GetType(FontChooser)) Is TypographicPropertyMetadata Then
                Dim displayName As String = LookupString([property].Name)
                items(count) = New TypographicFeatureListItem(displayName, [property])
                count += 1
            End If
        Next

        Array.Sort(items, 0, count)

        For i As Integer = 0 To count - 1
            featureList.Items.Add(items(i))
        Next
    End Sub

    Private Shared Function LookupString(ByVal tag As String) As String
        Return My.Resources.ResourceManager.GetString(tag, CultureInfo.CurrentUICulture)
    End Function

    Private ReadOnly Property CurrentTabState() As TabState
        Get
            Dim tab As TabState
            Return If(_tabDictionary.TryGetValue(TryCast(tabControl.SelectedItem, TabItem), tab), tab, Nothing)
        End Get
    End Property

    Private Sub InitializeSamplesTab()
        Dim selectedFamily As FontFamily = SelectedFontFamily

        Dim selectedFace As New Typeface(selectedFamily, SelectedFontStyle, SelectedFontWeight, SelectedFontStretch)

        fontFamilyNameRun.Text = FontFamilyListItem.GetDisplayName(selectedFamily)
        typefaceNameRun.Text = TypefaceListItem.GetDisplayName(selectedFace)

        ' Create FontFamily samples document.
        Dim doc As New FlowDocument()
        For Each face As Typeface In selectedFamily.GetTypefaces()
            Dim labelPara As New Paragraph(New Run(TypefaceListItem.GetDisplayName(face)))
            labelPara.Margin = New Thickness(0)
            doc.Blocks.Add(labelPara)

            Dim samplePara As New Paragraph(New Run(_previewSampleText))
            samplePara.FontFamily = selectedFamily
            samplePara.FontWeight = face.Weight
            samplePara.FontStyle = face.Style
            samplePara.FontStretch = face.Stretch
            samplePara.FontSize = 16.0
            samplePara.Margin = New Thickness(0, 0, 0, 8)
            doc.Blocks.Add(samplePara)
        Next

        fontFamilySamples.Document = doc

        ' Create typeface samples document.
        doc = New FlowDocument()
        For Each sizeInPoints As Double In New Double() {9.0, 10.0, 11.0, 12.0, 13.0, 14.0, 15.0, 16.0, 17.0}
            Dim labelText As String = String.Format("{0} {1}", sizeInPoints, _pointsText)
            Dim labelPara As New Paragraph(New Run(labelText))
            labelPara.Margin = New Thickness(0)
            doc.Blocks.Add(labelPara)

            Dim samplePara As New Paragraph(New Run(_previewSampleText))
            samplePara.FontFamily = selectedFamily
            samplePara.FontWeight = selectedFace.Weight
            samplePara.FontStyle = selectedFace.Style
            samplePara.FontStretch = selectedFace.Stretch
            samplePara.FontSize = FontSizeListItem.PointsToPixels(sizeInPoints)
            samplePara.Margin = New Thickness(0, 0, 0, 8)
            doc.Blocks.Add(samplePara)
        Next

        typefaceSamples.Document = doc
    End Sub

    Private Sub InitializeTypographyTab()
        If featureList.Items.IsEmpty Then
            InitializeFeatureList()
            featureList.SelectedIndex = 0

            AddHandler featureList.SelectionChanged, AddressOf featureList_SelectionChanged
        End If

        Dim chooserProperty As DependencyProperty = Nothing
        Dim featurePage As TypographyFeaturePage = Nothing

        Dim listItem As TypographicFeatureListItem = TryCast(featureList.SelectedItem, TypographicFeatureListItem)
        If Not listItem Is Nothing Then
            Dim metadata As TypographicPropertyMetadata = TryCast(listItem.ChooserProperty.GetMetadata(GetType(FontChooser)), TypographicPropertyMetadata)
            If Not metadata Is Nothing Then
                chooserProperty = listItem.ChooserProperty
                featurePage = metadata.FeaturePage
            End If
        End If

        InitializeFeaturePage(typographyFeaturePageGrid, chooserProperty, featurePage)
    End Sub

    Private Sub InitializeFeaturePage(ByVal grid As Grid, ByVal chooserProperty As DependencyProperty, ByVal page As TypographyFeaturePage)
        If page Is Nothing Then
            grid.Children.Clear()
            grid.RowDefinitions.Clear()
        Else
            ' Get the property value and metadata.
            Dim value As Object = Me.GetValue(chooserProperty)
            Dim metadata As TypographicPropertyMetadata = CType(chooserProperty.GetMetadata(GetType(FontChooser)), TypographicPropertyMetadata)

            ' Look up the sample text.
            Dim sampleText As String
            sampleText = If((Not metadata.SampleTextTag Is Nothing), LookupString(metadata.SampleTextTag), _defaultSampleText)

            If page Is _currentFeaturePage Then
                ' Update the state of the controls.
                For i As Integer = 0 To page.Items.Length - 1
                    ' Check the radio button if it matches the current property value.
                    If page.Items(i).Value.Equals(value) Then
                        Dim radioButton As RadioButton = CType(grid.Children(i * 2), RadioButton)
                        radioButton.IsChecked = True
                    End If

                    ' Apply properties to the sample text block.
                    Dim sample As TextBlock = CType(grid.Children(i * 2 + 1), TextBlock)
                    sample.Text = sampleText
                    ApplyPropertiesToObjectExcept(sample, chooserProperty)
                    sample.SetValue(metadata.TargetProperty, page.Items(i).Value)
                Next
            Else
                grid.Children.Clear()
                grid.RowDefinitions.Clear()

                ' Add row definitions.
                For i As Integer = 0 To page.Items.Length - 1
                    Dim row As New RowDefinition()
                    row.Height = GridLength.Auto
                    grid.RowDefinitions.Add(row)
                Next

                ' Add the controls.
                For i As Integer = 0 To page.Items.Length - 1
                    Dim tag As String = page.Items(i).Tag
                    Dim radioContent As New TextBlock(New Run(LookupString(tag)))
                    radioContent.TextWrapping = TextWrapping.Wrap

                    ' Add the radio button.
                    Dim radioButton As New RadioButton()
                    radioButton.Name = tag
                    radioButton.Content = radioContent
                    radioButton.Margin = New Thickness(5.0, 0.0, 0.0, 0.0)
                    radioButton.VerticalAlignment = VerticalAlignment.Center
                    grid.SetRow(radioButton, i)
                    grid.Children.Add(radioButton)

                    ' Check the radio button if it matches the current property value.
                    If page.Items(i).Value.Equals(value) Then
                        radioButton.IsChecked = True
                    End If

                    ' Hook up the event.
                    AddHandler radioButton.Checked, AddressOf featureRadioButton_Checked

                    ' Add the block with sample text.
                    Dim sample As New TextBlock(New Run(sampleText))
                    sample.Margin = New Thickness(5.0, 5.0, 5.0, 0.0)
                    sample.TextWrapping = TextWrapping.WrapWithOverflow
                    ApplyPropertiesToObjectExcept(sample, chooserProperty)
                    sample.SetValue(metadata.TargetProperty, page.Items(i).Value)
                    grid.SetRow(sample, i)
                    grid.SetColumn(sample, 1)
                    grid.Children.Add(sample)
                Next

                ' Add borders between rows.
                For i As Integer = 0 To page.Items.Length - 1
                    Dim border As New Border()
                    border.BorderThickness = New Thickness(0.0, 0.0, 0.0, 1.0)
                    border.BorderBrush = SystemColors.ControlLightBrush
                    grid.SetRow(border, i)
                    grid.SetColumnSpan(border, 2)
                    grid.Children.Add(border)
                Next
            End If
        End If

        _currentFeature = chooserProperty
        _currentFeaturePage = page
    End Sub

    Private Sub featureRadioButton_Checked(ByVal sender As Object, ByVal e As RoutedEventArgs)
        If Not _currentFeature Is Nothing AndAlso Not _currentFeaturePage Is Nothing Then
            Dim tag As String = (CType(sender, RadioButton)).Name

            For Each item As TypographyFeaturePage.Item In _currentFeaturePage.Items
                If item.Tag Is tag Then
                    Me.SetValue(_currentFeature, item.Value)
                End If
            Next
        End If
    End Sub

    Private Sub AddTableRow(ByVal rowGroup As TableRowGroup, ByVal leftText As String, ByVal rightText As String)
        Dim row As New TableRow()

        row.Cells.Add(New TableCell(New Paragraph(New Run(leftText))))
        row.Cells.Add(New TableCell(New Paragraph(New Run(rightText))))

        rowGroup.Rows.Add(row)
    End Sub

    Private Sub AddTableRow(ByVal rowGroup As TableRowGroup, ByVal leftText As String, ByVal rightStrings As IDictionary(Of CultureInfo, String))
        Dim rightText As String = NameDictionaryHelper.GetDisplayName(rightStrings)
        AddTableRow(rowGroup, leftText, rightText)
    End Sub

    Private Sub InitializeDescriptiveTextTab()
        Dim selectedTypeface As New Typeface(SelectedFontFamily, SelectedFontStyle, SelectedFontWeight, SelectedFontStretch)

        Dim glyphTypeface As GlyphTypeface
        If selectedTypeface.TryGetGlyphTypeface(glyphTypeface) Then
            ' Create a table with two columns.
            Dim table As New Table()
            table.CellSpacing = 5
            Dim leftColumn As New TableColumn()
            leftColumn.Width = New GridLength(2.0, GridUnitType.Star)
            table.Columns.Add(leftColumn)
            Dim rightColumn As New TableColumn()
            rightColumn.Width = New GridLength(3.0, GridUnitType.Star)
            table.Columns.Add(rightColumn)

            Dim rowGroup As New TableRowGroup()
            AddTableRow(rowGroup, "Family:", glyphTypeface.FamilyNames)
            AddTableRow(rowGroup, "Face:", glyphTypeface.FaceNames)
            AddTableRow(rowGroup, "Description:", glyphTypeface.Descriptions)
            AddTableRow(rowGroup, "Version:", glyphTypeface.VersionStrings)
            AddTableRow(rowGroup, "Copyright:", glyphTypeface.Copyrights)
            AddTableRow(rowGroup, "Trademark:", glyphTypeface.Trademarks)
            AddTableRow(rowGroup, "Manufacturer:", glyphTypeface.ManufacturerNames)
            AddTableRow(rowGroup, "Designer:", glyphTypeface.DesignerNames)
            AddTableRow(rowGroup, "Designer URL:", glyphTypeface.DesignerUrls)
            AddTableRow(rowGroup, "Vendor URL:", glyphTypeface.VendorUrls)
            AddTableRow(rowGroup, "Win32 Family:", glyphTypeface.Win32FamilyNames)
            AddTableRow(rowGroup, "Win32 Face:", glyphTypeface.Win32FaceNames)

            Try
                AddTableRow(rowGroup, "Font File URI:", glyphTypeface.FontUri.ToString())
            Catch e1 As System.Security.SecurityException
                ' Font file URI is privileged information; just skip it if we don't have access.
            End Try

            table.RowGroups.Add(rowGroup)

            fontDescriptionBox.Document = New FlowDocument(table)

            fontLicenseBox.Text = NameDictionaryHelper.GetDisplayName(glyphTypeface.LicenseDescriptions)
        Else
            fontDescriptionBox.Document = New FlowDocument()
            fontLicenseBox.Text = String.Empty
        End If
    End Sub

    Private Sub InitializePreview()
        ApplyPropertiesToObject(previewTextBox)
    End Sub

#End Region

#Region "List box helpers"

    ' Update font family list based on selection.
    ' Return list item if there's an exact match, or null if not.
    Private Function SelectFontFamilyListItem(ByVal displayName As String) As FontFamilyListItem
        Dim listItem As FontFamilyListItem = TryCast(fontFamilyList.SelectedItem, FontFamilyListItem)
        If Not listItem Is Nothing AndAlso String.Compare(listItem.ToString(), displayName, True, CultureInfo.CurrentCulture) = 0 Then
            ' Already selected
            Return listItem
        ElseIf SelectListItem(fontFamilyList, displayName) Then
            ' Exact match found
            Return TryCast(fontFamilyList.SelectedItem, FontFamilyListItem)
        Else
            ' Not in the list
            Return Nothing
        End If
    End Function

    ' Update font family list based on selection.
    ' Return list item if there's an exact match, or null if not.
    Private Function SelectFontFamilyListItem(ByVal family As FontFamily) As FontFamilyListItem
        Dim listItem As FontFamilyListItem = TryCast(fontFamilyList.SelectedItem, FontFamilyListItem)
        If Not listItem Is Nothing AndAlso listItem.FontFamily.Equals(family) Then
            ' Already selected
            Return listItem
        ElseIf SelectListItem(fontFamilyList, FontFamilyListItem.GetDisplayName(family)) Then
            ' Exact match found
            Return TryCast(fontFamilyList.SelectedItem, FontFamilyListItem)
        Else
            ' Not in the list
            Return Nothing
        End If
    End Function

    ' Update typeface list based on selection.
    ' Return list item if there's an exact match, or null if not.
    Private Function SelectTypefaceListItem(ByVal typeface As Typeface) As TypefaceListItem
        Dim listItem As TypefaceListItem = TryCast(typefaceList.SelectedItem, TypefaceListItem)
        If Not listItem Is Nothing AndAlso listItem.Typeface.Equals(typeface) Then
            ' Already selected
            Return listItem
        ElseIf SelectListItem(typefaceList, New TypefaceListItem(typeface)) Then
            ' Exact match found
            Return TryCast(typefaceList.SelectedItem, TypefaceListItem)
        Else
            ' Not in list
            Return Nothing
        End If
    End Function

    ' Update list based on selection.
    ' Return true if there's an exact match, or false if not.
    Private Function SelectListItem(ByVal list As ListBox, ByVal value As Object) As Boolean
        Dim itemList As ItemCollection = list.Items

        ' Perform a binary search for the item.
        Dim first As Integer = 0
        Dim limit As Integer = itemList.Count

        Do While first < limit - 1
            Dim i As Integer = first + (limit - first) / 2
            Dim item As IComparable = CType(itemList(i), IComparable)
            Dim comparison As Integer = item.CompareTo(value)
            If comparison < 0 Then
                ' Value must be after i
                first = i + 1
            ElseIf comparison > 0 Then
                ' Value must be before i
                limit = i
            Else
                ' Exact match; select the item.
                list.SelectedIndex = i
                itemList.MoveCurrentToPosition(i)
                list.ScrollIntoView(itemList(i))
                Return True
            End If
        Loop

        ' Not an exact match; move current position to the nearest item but don't select it.
        If itemList.Count > 0 Then
            Dim i As Integer = Math.Min(first, itemList.Count - 1)
            itemList.MoveCurrentToPosition(i)
            list.ScrollIntoView(itemList(i))
        End If

        Return False
    End Function

    ' Logic to handle UP and DOWN arrow keys in the text box associated with a list.
    ' Behavior is similar to a Win32 combo box.
    Private Sub OnComboBoxPreviewKeyDown(ByVal textBox As TextBox, ByVal listBox As ListBox, ByVal e As KeyEventArgs)
        Select Case e.Key
            Case Key.Up
                ' Move up from the current position.
                MoveListPosition(listBox, -1)
                e.Handled = True

            Case Key.Down
                ' Move down from the current position, unless the item at the current position is
                ' not already selected in which case select it.
                If listBox.Items.CurrentPosition = listBox.SelectedIndex Then
                    MoveListPosition(listBox, +1)
                Else
                    MoveListPosition(listBox, 0)
                End If
                e.Handled = True
        End Select
    End Sub

    Private Sub MoveListPosition(ByVal listBox As ListBox, ByVal distance As Integer)
        Dim i As Integer = listBox.Items.CurrentPosition + distance
        If i >= 0 AndAlso i < listBox.Items.Count Then
            listBox.Items.MoveCurrentToPosition(i)
            listBox.SelectedIndex = i
            listBox.ScrollIntoView(listBox.Items(i))
        End If
    End Sub

#End Region
End Class
