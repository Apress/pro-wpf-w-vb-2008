Imports System.Windows.Ink

Public Class ColorPickerDialog

    Private m_selectedDA As DrawingAttributes


    ' Completes initialization after all XAML member vars have been initialized.
    Protected Overrides Sub OnInitialized(ByVal e As EventArgs)
        MyBase.OnInitialized(e)

        m_selectedDA = New DrawingAttributes()
        UpdateControlValues()
        UpdateControlVisuals()

        AddHandler colorComb.ColorSelected, AddressOf colorComb_ColorSelected
        AddHandler brightnessSlider.ValueChanged, AddressOf brightnessSlider_ValueChanged
        AddHandler opacitySlider.ValueChanged, AddressOf opacitySlider_ValueChanged
        AddHandler ellipticalRadio.Checked, AddressOf radio_Click
        AddHandler rectangularRadio.Checked, AddressOf radio_Click
        AddHandler ignorepsiCheckbox.Click, AddressOf checkbox_Click
        AddHandler fitcurveCheckbox.Click, AddressOf checkbox_Click
        AddHandler decrementThickness.Click, AddressOf decrementThickness_Click
        AddHandler incrementThickness.Click, AddressOf incrementThickness_Click

        AddHandler acceptButton.Click, AddressOf acceptButton_Click
        AddHandler cancelButton.Click, AddressOf cancelButton_Click
    End Sub

    '
    ' Interface

    Public Property SelectedDrawingAttributes() As DrawingAttributes
        Get
            Return m_selectedDA
        End Get
        Set(ByVal value As DrawingAttributes)
            m_selectedDA = value
            UpdateControlValues()
            UpdateControlVisuals()
        End Set
    End Property

    '
    ' Implementation

    Private _notUserInitiated As Boolean

    ' Updates values of controls when new DA is set (or upon initialization).
    Private Sub UpdateControlValues()
        _notUserInitiated = True
        Try
            ' Set nominal color on comb.
            Dim nc As Color = m_selectedDA.Color
            Dim f As Single = Math.Max(Math.Max(nc.ScR, nc.ScG), nc.ScB)
            If f < 0.001F Then ' black
                nc = Color.FromScRgb(1.0F, 1.0F, 1.0F, 1.0F)
            Else
                nc = Color.FromScRgb(1.0F, nc.ScR / f, nc.ScG / f, nc.ScB / f)
            End If
            colorComb.SelectedColor = nc

            ' Set brightness and opacity.
            brightnessSlider.Value = f
            If m_selectedDA.IsHighlighter Then
                opacitySlider.Value = 0.5
                opacitySlider.IsEnabled = False
            Else
                opacitySlider.Value = m_selectedDA.Color.ScA
            End If

            ' Set stylus characteristics.
            ellipticalRadio.IsChecked = (m_selectedDA.StylusTip = StylusTip.Ellipse)
            rectangularRadio.IsChecked = (m_selectedDA.StylusTip = StylusTip.Rectangle)
            ignorepsiCheckbox.IsChecked = (m_selectedDA.IgnorePressure)
            fitcurveCheckbox.IsChecked = (m_selectedDA.FitToCurve)
        Finally
            _notUserInitiated = False
        End Try
    End Sub

    ' Updates visual properties of all controls, in response to any change.
    Private Sub UpdateControlVisuals()
        Dim c As Color = m_selectedDA.Color

        ' Update LGB for brightnessSlider
        Dim sb1 As Border = TryCast(brightnessSlider.Parent, Border)
        Dim lgb1 As LinearGradientBrush = TryCast(sb1.Background, LinearGradientBrush)
        lgb1.GradientStops(1).Color = colorComb.SelectedColor

        ' Update LGB for opacitySlider
        Dim c2a As Color = Color.FromScRgb(0.0F, c.ScR, c.ScG, c.ScB)
        Dim c2b As Color = Color.FromScRgb(1.0F, c.ScR, c.ScG, c.ScB)
        Dim sb2 As Border = TryCast(opacitySlider.Parent, Border)
        Dim lgb2 As LinearGradientBrush = TryCast(sb2.Background, LinearGradientBrush)
        lgb2.GradientStops(0).Color = c2a
        lgb2.GradientStops(1).Color = c2b

        ' Update thickness
        m_selectedDA.Width = Math.Round(m_selectedDA.Width, 2)
        thicknessTextbox.Text = m_selectedDA.Width.ToString()

        ' Update DA on previewPresenter
        For Each s As Stroke In previewPresenter.Strokes
            s.DrawingAttributes = m_selectedDA
        Next
    End Sub

    '
    ' Event Handlers

    Private Sub colorComb_ColorSelected(ByVal sender As Object, ByVal e As ColorEventArgs)
        If _notUserInitiated Then
            Return
        End If

        Dim a, f, r, g, b As Single
        a = CSng(opacitySlider.Value)
        f = CSng(brightnessSlider.Value)

        Dim nc As Color = e.Color
        r = f * nc.ScR
        g = f * nc.ScG
        b = f * nc.ScB

        m_selectedDA.Color = Color.FromScRgb(a, r, g, b)
        UpdateControlVisuals()
    End Sub

    Private Sub brightnessSlider_ValueChanged(ByVal sender As Object, ByVal e As RoutedPropertyChangedEventArgs(Of Double))
        If _notUserInitiated Then
            Return
        End If

        Dim nc As Color = colorComb.SelectedColor
        Dim f As Single = CSng(e.NewValue)

        Dim a, r, g, b As Single
        a = CSng(opacitySlider.Value)
        r = f * nc.ScR
        g = f * nc.ScG
        b = f * nc.ScB

        m_selectedDA.Color = Color.FromScRgb(a, r, g, b)
        UpdateControlVisuals()
    End Sub

    Private Sub opacitySlider_ValueChanged(ByVal sender As Object, ByVal e As RoutedPropertyChangedEventArgs(Of Double))
        If _notUserInitiated Then
            Return
        End If

        Dim c As Color = m_selectedDA.Color
        Dim a As Single = CSng(e.NewValue)

        m_selectedDA.Color = Color.FromScRgb(a, c.ScR, c.ScG, c.ScB)
        UpdateControlVisuals()
    End Sub

    Private Sub radio_Click(ByVal sender As Object, ByVal e As RoutedEventArgs)
        If _notUserInitiated Then
            Return
        End If

        If sender Is ellipticalRadio Then
            m_selectedDA.StylusTip = StylusTip.Ellipse
        End If
        If sender Is rectangularRadio Then
            m_selectedDA.StylusTip = StylusTip.Rectangle
        End If
    End Sub

    Private Sub checkbox_Click(ByVal sender As Object, ByVal e As RoutedEventArgs)
        If _notUserInitiated Then
            Return
        End If

        If sender Is ignorepsiCheckbox Then
            m_selectedDA.IgnorePressure = (ignorepsiCheckbox.IsChecked = True)
        End If
        If sender Is fitcurveCheckbox Then
            m_selectedDA.FitToCurve = (fitcurveCheckbox.IsChecked = True)
        End If

        UpdateControlVisuals()
    End Sub

    Private Sub incrementThickness_Click(ByVal sender As Object, ByVal e As RoutedEventArgs)
        If _notUserInitiated Then
            Return
        End If

        If m_selectedDA.Width < 1.0 Then
            m_selectedDA.Width += 0.1
            m_selectedDA.Height += 0.1
        ElseIf m_selectedDA.Width < 10.0 Then
            m_selectedDA.Width += 0.5
            m_selectedDA.Height += 0.5
        Else
            m_selectedDA.Width += 1.0R
            m_selectedDA.Height += 1.0R
        End If

        UpdateControlVisuals()
    End Sub

    Private Sub decrementThickness_Click(ByVal sender As Object, ByVal e As RoutedEventArgs)
        If _notUserInitiated Then
            Return
        End If

        If m_selectedDA.Width < 0.1001 Then
            Return
        End If

        If m_selectedDA.Width < 1.001 Then
            m_selectedDA.Width -= 0.1
            m_selectedDA.Height -= 0.1
        ElseIf m_selectedDA.Width < 10.001 Then
            m_selectedDA.Width -= 0.5
            m_selectedDA.Height -= 0.5
        Else
            m_selectedDA.Width -= 1.0R
            m_selectedDA.Height -= 1.0R
        End If

        UpdateControlVisuals()
    End Sub

    Private Sub acceptButton_Click(ByVal sender As Object, ByVal e As RoutedEventArgs)
        ' Setting this property closes the dialog, when shown modally.
        Me.DialogResult = True
    End Sub

    Private Sub cancelButton_Click(ByVal sender As Object, ByVal e As RoutedEventArgs)
        ' Setting this property closes the dialog, when shown modally.
        Me.DialogResult = False
    End Sub

End Class