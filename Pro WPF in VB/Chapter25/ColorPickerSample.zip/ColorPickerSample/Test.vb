Public Class Test
    <STAThread()> _
    Shared Sub Main()
        Dim cpd As New ColorPickerDialog()
        cpd.ShowDialog()
    End Sub
End Class